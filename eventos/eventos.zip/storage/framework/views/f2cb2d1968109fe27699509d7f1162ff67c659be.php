

<?php $__env->startSection('header'); ?>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="container">
        
        <form action="<?php echo e(route('areaAtuacao', ['id' => $id])); ?>" method="post">        
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nome">Area de conhecimento :</label>
                <input type="text" id="area" name="area" placeholder="Adicione a Area de Conhecimento" value="<?php echo isset($_POST['area']) ? $_POST['area'] : ''; ?>">
            </div>           

            <!-- Adicione mais campos conforme necessário -->
            <div class="dvbtn5">
                <input type="submit" value="Voltar" class="btnVoltar" name="btnVoltarArea">
                <input type="submit" value="Inserir" class="btnConfirm" name="btnArea">
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modeloGenerico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventos\resources\views/areaAtuacao.blade.php ENDPATH**/ ?>