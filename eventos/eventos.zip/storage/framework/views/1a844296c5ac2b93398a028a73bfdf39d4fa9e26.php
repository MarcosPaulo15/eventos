<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/login.css">
    <title>Document</title>
</head>
<body>
    <header>
        <?php echo $__env->yieldContent('header'); ?>
        
    </header>
    <main class="container-fluid">
        <?php echo $__env->yieldContent('main'); ?> 
    </main>
    <footer> 
        <?php echo $__env->yieldContent('footer'); ?>
    </footer>

<?php echo $__env->yieldContent('modeloBody'); ?>    
</body>
</html><?php /**PATH C:\xampp\htdocs\eventos\resources\views/modelo.blade.php ENDPATH**/ ?>