

<?php $__env->startSection('header'); ?>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>


<?php
foreach($resultEvent as $q){

    //$nome = $p->nome;
}
?>
   
   <div class="container">       
        
        <center>
            <label for="nome" ><B>Evento : <?php echo $q->nome; ?></B></label>
        </center>
    
        <br>
        <br>
        <form action="<?php echo e(route('addUser', ['id' => $id])); ?>" method="post">                
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nome"><b>usuarios</b><span style="color: red;">*</span> :</label>
                <select name="user_id">
                <option value="0">-</option>
                <?php 
                    foreach($result as $p){

                        //$nome = $p->nome;
                     ?>
                    <option value="<?php echo $p->id?>"><?php echo $p->nome ?></option>
                    <?php
                    }
                    //}?>                
                </select>
            </div>
            <div class="form-group">
                <label for="email"><b>Perfil</b><span style="color: red;">*</span> :</label>
                <select name="usrPerfil" id="">
                    <option value="0">-</option>
                    <option value="1">Administrador</option>
                    <option value="2">Financeiro</option>
                    <option value="3">Coordenação Comissão Científica</option>
                    <option value="4">Avaliador</option>
                    <option value="5">Monitor</option>
                    <option value="6">Coordenação Inscrições</option>
                    <option value="7">Coordenação de Monitores</option>
                    <option value="8">Coordenação Geral de Evento</option>
                </select>
            </div>

            <!-- Adicione mais campos conforme necessário -->
            <div class="dvbtn">
                <input type="submit" value="Adicionar" class="btnAddUserEv" name="btnAddUserEv">
                <input type="submit" value="Cancelar" class="btnBackEv" name="btnBackEv">                
            </div>
        </form>
    </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modeloGenerico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventos\resources\views/addUserEvent.blade.php ENDPATH**/ ?>