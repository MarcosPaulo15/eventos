

<?php $__env->startSection('header'); ?>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<?php
    foreach($nome as $q){

    }
?>
    <div class="container">
                <center>
                    <label><b><?php echo $q->nome?></b></label>
                </center>

                <br>
                <br>
        
        <form action="<?php echo e(route('usuariosVinculados', ['id' => $id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <div class="tables">

                    <table>
                        <div class="tableTitle">
                            <th>
                                <th>usuarios Vinculados</th>
                            </th>
                        </div>
                        <br>
                        <br>

                        <?php

                                foreach($resultado as $p){
                        ?>
                            <tr>                                
                                <td> <?php echo $p->nome; ?> </td>
                            </tr>
                        

                        <?php
                        }
                        
                        ?>
                    </table>
                </div>
                
                <br>
                <div>
                    <center>
                        <input type="submit" value="Voltar" class="btnBack" name="btnVoltarUsu">
                    </center>
                </div>                                
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modeloGenerico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eventos\resources\views/VizualizaUsuario.blade.php ENDPATH**/ ?>